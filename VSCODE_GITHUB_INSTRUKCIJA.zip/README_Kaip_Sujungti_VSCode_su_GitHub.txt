
📘 README_Kaip_Sujungti_VSCode_su_GitHub.txt

Ši instrukcija padės labai aiškiai ir konkrečiai, kaip sujungti savo projektą VS Code su GitHub.

============================
1️⃣ Atidaryk savo projektą
============================

🔹 Sukurk arba turėk savo projekto aplanką (pvz.: „mano-projektas“)
🔹 Atidaryk VS Code
🔹 Spausk „File → Open Folder...“
🔹 Pasirink tą aplanką (pvz. Desktop → mano-projektas)

🟡 SVARBU: Terminale visada turi būti tame aplanke!

Tarkim tavo kelias atrodo taip:
C:/Users/Tu/Desktop/mano-projektas

Kai atidarai terminalą, matysi:
PS C:\Users\Tu\Desktop\mano-projektas>

============================
2️⃣ Paleisk GIT
============================

✳️ Terminale (kai esi savo projekto aplanke), įvesk:

git init

Tai sukurs paslėptą aplanką .git, kuris pradės sekti visus failus

============================
3️⃣ Pridėk failus
============================

git add .

Tai pridės visus failus

============================
4️⃣ Padaryk pirmą commit
============================

git commit -m "Pirmas komitas"

Tai užfiksuos dabartinę projekto versiją

============================
5️⃣ Sukurk repozitoriją GitHub'e
============================

🔹 Nueik į https://github.com
🔹 Spaudi "New repository"
🔹 Įrašyk pavadinimą (pvz. mano-projektas)
🔹 ❗ NEPAŽYMĖK „Initialize with README“
🔹 Spaudi "Create repository"

GitHub parodys tau nuorodą kaip šią:

https://github.com/TavoVardas/mano-projektas.git

============================
6️⃣ Susiek VSCode su GitHub
============================

Terminale įvesk:

git remote add origin https://github.com/TavoVardas/mano-projektas.git

(Pakeisk nuorodą į savo tikrą)

============================
7️⃣ Nusiųsk į GitHub
============================

git branch -M main
git push -u origin main

Jei paprašys prisijungti – naudok GitHub username ir personal access token (vietoj slaptažodžio)

============================
8️⃣ Ateities komandos
============================

Kiekvieną kartą, kai ką nors keiti:

git add .
git commit -m "Atnaujinimai"
git push

============================
✅ Viskas! Tavo VS Code dabar prijungtas prie GitHub!
============================
