
✅ GALUTINIS EGZAMINO RINKINYS – KAIP NAUDOTIS

📁 1_Sufleris_Pilnas_IT_Egzaminas.pdf
– Greitas HTML, CSS, JS, MySQL sufleris
– Ieškok per egzaminą:
  - HTML tagai – <form>, <input>, <button>
  - CSS – spalvos, tarpai, dydžiai
  - JS – if, for, eventai
  - SQL – SELECT, INSERT, WHERE

📁 2_Interneto_Pagalba_Be_AI.txt
– Kaip googlinti be AI
– Svetainės: w3schools.com, mdn, stackoverflow
– Pvz.:
  - html input required w3schools
  - create table mysql site:w3schools.com

📁 Projektas_EgzaminoPagalba_FULL
– Pavyzdinis projektas su registracija, prisijungimu, PHP, duomenų baze
– Naudok kaip pagrindą – veikia su XAMPP
– Atidaryk `index.html` ir `register.php` / `login.php`

📁 Projektas_Paslaugos
– Papildomas projektas su paslaugų valdymu
– Rodymas, įrašymas, filtravimas

🎯 PATARIMAS:
– Paleisk XAMPP
– Įsikelk projektą į `htdocs/`
– Naudok phpMyAdmin → import SQL
– Jei neveikia – naudok suflerį arba googlink

🟢 NEBIJOK KLAIDŲ – svarbu parodyti, kad „dariau, veikia arba beveik veikia“
