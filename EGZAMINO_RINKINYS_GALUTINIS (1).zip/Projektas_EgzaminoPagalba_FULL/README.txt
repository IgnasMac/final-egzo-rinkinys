🧾 EGZAMINO PAGALBA – VISKAS PAPRASTAI

📂 Tavo projektas turi 3 svarbias dalis:

1. frontend – tai tavo svetainė (login, register ir t.t.)
2. backend – tai serveris, kuris priima duomenis
3. MySQL (XAMPP) – duomenų bazė, kur saugomi vartotojai ir paslaugos

---------------------------------------

🔎 Kur ką rasti:

✅ FRONTEND failai:
  - App.js — frontend/src/App.js
  - RegisterPage.jsx — frontend/src/pages/RegisterPage.jsx
  - LoginPage.jsx — frontend/src/pages/LoginPage.jsx
  - index.html — frontend/public/index.html

✅ BACKEND failas:
  - server.js — backend/server.js

✅ DUOMENŲ BAZĖ:
  - MySQL per XAMPP -> eik į localhost/phpmyadmin

---------------------------------------

📌 Dažniausios komandos (rašyti terminale):

1. Paleisti frontend:
   cd frontend
   npm install
   npm start

2. Paleisti backend:
   cd backend
   npm install
   node server.js

---------------------------------------

❗ SVARBU:
Jeigu rodo klaidas su "npm start" — įsitikink, kad esi frontend aplanke!
Jeigu nori registruotis — backend turi veikti ir MySQL paleistas!

---------------------------------------

✅ Sėkmės! Jei reikia, grįžk ir parašyk "padėk" :)

