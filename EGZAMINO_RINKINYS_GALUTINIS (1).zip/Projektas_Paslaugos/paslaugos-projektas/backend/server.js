const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

// Test: GET /labas
app.get('/labas', (req, res) => {
  res.send('Testas veikia!');
});

// GET /api/providers
app.get('/api/providers', (req, res) => {
  const sql = 'SELECT * FROM providers';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('DB klaida:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(results);
  });
});

// POST /api/providers
app.post('/api/providers', (req, res) => {
  const { first_name, last_name, profession, city, image_url } = req.body;

  const sql = `
    INSERT INTO providers (first_name, last_name, profession, city, image_url)
    VALUES (?, ?, ?, ?, ?)
  `;

  db.query(sql, [first_name, last_name, profession, city, image_url], (err, result) => {
    if (err) {
      console.error('DB klaida:', err);
      return res.status(500).json({ error: 'Nepavyko pridėti' });
    }
    res.status(201).json({ message: 'Pridėta sėkmingai', id: result.insertId });
  });
});

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Serveris paleistas ant http://localhost:${PORT}`);
});

// DELETE /api/providers/:id
app.delete('/api/providers/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM providers WHERE id = ?';

  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('DB klaida:', err);
      return res.status(500).json({ error: 'Nepavyko ištrinti' });
    }
    res.json({ message: 'Ištrinta sėkmingai' });
  });
});