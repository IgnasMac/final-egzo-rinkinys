const mysql = require('mysql');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'paslaugos'
});

db.connect((err) => {
  if (err) {
    console.error('❌ Nepavyko prisijungti prie MySQL:', err);
  } else {
    console.log('✅ Prisijungta prie MySQL!');
  }
});

module.exports = db;